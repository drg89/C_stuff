/* Tweet cleanser:
 * Removes non-alphanumeric characters from tweets
 *
 * Skeleton code written by Yi Han and Jianzhong Qi, April 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/* stage numbers */
#define STAGE_NUM_ONE 1 
#define STAGE_NUM_TWO 2
#define STAGE_NUM_THREE 3
#define STAGE_NUM_FOUR 4
#define STAGE_NUM_FIVE 5
#define STAGE_HEADER "Stage %d\n==========\n"	/* stage header format string */

#define MAX_TWEET_LENGTH 280					/* maximum length of a tweet */
#define MAX_NUM_TWEETS 100						/* maximum number of tweets */

typedef char tweet_t[MAX_TWEET_LENGTH+1];		/* a tweet */

/****************************************************************/

/* function prototypes */
void read_one_tweet(tweet_t one_tweet, int max_len);
void print_stage_header(int stage_num);
void tweet_tolower(tweet_t one_tweet);

void stage_one(tweet_t one_tweet);
void stage_two(tweet_t tweets[], int *num_tweets);
void stage_three(tweet_t tweets[], int num_tweets);
void stage_four(tweet_t tweets[], int num_tweets);
void stage_five(tweet_t tweets[], int num_tweets);

/* add your own function prototypes here */


/****************************************************************/

/* main function controls all the action, do NOT modify this function */
int
main(int argc, char *argv[]) {
	/* to hold all input tweets */
	tweet_t tweets[MAX_NUM_TWEETS];	
	/* to hold the number of input tweets */
	int num_tweets = 0;					

	/* stage 1: reading the first tweet */
	stage_one(tweets[num_tweets]); 
	num_tweets++;
	
	/* stage 2: removing non-alphanumeric characters */
	stage_two(tweets, &num_tweets);
	
	/* stage 3: removing extra asterisks and finding the longest tweet */ 
	stage_three(tweets, num_tweets);
	
	/* stage 4: finding the non-contained tweets */
	stage_four(tweets, num_tweets);
	
	/* stage 5: sorting the tweets */
	stage_five(tweets, num_tweets);
	
	/* all done; take some rest */
	return 0;
}

/* read a line of input into one_tweet */
void
read_one_tweet(tweet_t one_tweet, int max_len) {
	int i = 0, c;
	
	while (((c = getchar()) != EOF) && (c != '\n') && (c != '\r')) {
		if (i < max_len) {
			one_tweet[i++] = c;
		} else {
			printf("Invalid input line, toooooooo long.\n");
			exit(EXIT_FAILURE);
		}
	}
	one_tweet[i] = '\0';
}

/* print stage header given stage number */
void 
print_stage_header(int stage_num) {
	printf(STAGE_HEADER, stage_num);
}

/****************************************************************/
/* add your code below */

/* scan a tweet and convert all English letters into lowercase */
void 
tweet_tolower(tweet_t one_tweet) {
	/* add code here to convert English letters in one_tweet into lowercase */
	
}

/* stage 1: reading the first tweet */
void 
stage_one(tweet_t one_tweet) {
	/* print stage header */
	print_stage_header(STAGE_NUM_ONE);
	
	/* add code to call the read_one_tweet function to read the first tweet */ 
	
	
	/* add code into the tweet_tolower function 
	 * to convert English letters into lowercase 
	 */
	tweet_tolower(one_tweet);
	
	/* print result */
	printf("%s\n\n", one_tweet);
}

/* stage 2: removing non-alphanumeric characters */
void 
stage_two(tweet_t tweets[], int *num_tweets) {
	/* add code for stage 2 */
	
}

/* stage 3: removing extra asterisks and finding the longest tweet */ 
void 
stage_three(tweet_t tweets[], int num_tweets) {
	/* add code for stage 3 */
	
}

/* stage 4: finding the non-contained tweets */
void 
stage_four(tweet_t tweets[], int num_tweets) {
	/* add code for stage 4 */
	
}

/* stage 5: sorting the tweets */
void 
stage_five(tweet_t tweets[], int num_tweets) {
	/* add code for stage 5 (optional stage) */
	
}
